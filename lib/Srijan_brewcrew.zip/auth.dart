import 'package:brew_crew/user.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {

  final FirebaseAuth _auth = FirebaseAuth.instance;
  //create user object based on FirebaseUser
   _userFromFirebaseUser(User user){
    return user != null ? TheUser(uid: user.uid) : null;
  }

  //auth change user stream
  Stream <TheUser> get user{
    return _auth.authStateChanges().map((User user) => _userFromFirebaseUser(user));
    }

  //sign in anonymously

Future signInAnon() async {
  try{
      UserCredential result = await _auth.signInAnonymously();
      User user = result.user;
      return _userFromFirebaseUser(user);
  }catch(e){
    print(e.toString());
    return null;
  }
}
  //sign in with email & pwd

  //register with email & pwd

  //sign out
}